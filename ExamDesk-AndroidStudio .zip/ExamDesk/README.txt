Exam Desk - Android Studio project
1. Open Android Studio > File > Open > select this "ExamDesk" folder.
2. Wait for Gradle sync (needs internet the first time).
3. Plug in your phone (USB debugging on) and press Run, or build the APK:
   Build > Build Bundle(s) / APK(s) > Build APK(s)
4. APK location: app/build/outputs/apk/debug/app-debug.apk
To change the app, edit app/src/main/assets/index.html

Cloud build (no Android Studio): push this folder to a GitHub repo.
The workflow in .github/workflows/build.yml builds the APK automatically.
Download it from the repo > Actions > latest run > Artifacts > ExamDesk-apk.
